for person in people:

#     print(f'Current Person: {person}')
