person = {
    'first_name':'Jawad',
    'last_name': 'Ahmad',
    'age' : 30
}

print(person, type(person))


# list of dicts

people = [

    {'name':'Jawad', 'age':30},
    {'name':'Armeena', 'age':5}

]

print(people[1]['name'])
