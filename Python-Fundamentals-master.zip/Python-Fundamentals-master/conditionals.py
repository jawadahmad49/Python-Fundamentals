# If / Else conditions are used to decide to do something based on something true or false


x = 5
y = 20

# Comparison Operators (==, !=, >, <, >=, <=) - Used to compare values

if x>y:
    print(f'{x} is greater than {y}')


# if / else

if x>y:
     print(f'{x} is greater than {y}')
else:
    print(f'{x} is less than {y}')
